package com.atomone.Secureinspect;

import android.content.Context;

class SecureApi {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("Secure-lib");
    }


    /**
     * 调试状态检测
     *
     * @return
     */
    public native int debugCheck();

    /**
     * Root检测
     *
     * @return
     */
    public native int rootCheck();

    /**
     * 注入、hook 检测
     * 例如 Xposed 等
     *
     * @return
     */
    public native int injectCheck();

    /**
     * 模拟器检测
     *
     * @return
     */
    public native int emulatorCheck(Context mContext);

    /**
     * app签名校验,防止重打包
     *
     * @return
     */
    public native int signPackageCheck(Context mContext, IVerifyListener verifyListener);


    /**
     * 根据APP的包名获取签名
     */
    public native String getRemoteAppSign(Context mContext, String pkgName);

    /**
     * 是否运行在VirtualApp 中
     * @return
     */
    public native  int isRunInVa();

    /**
     * 是否处于多开环境
     * @return
     */
    public native  int isMultiOpen();

}
