package com.atomone.Secureinspect;

public class SecureException extends RuntimeException {

    public SecureException(String message) {
        super(message);
    }
}
