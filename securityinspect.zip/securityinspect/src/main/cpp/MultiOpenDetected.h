//
// Created by Administrator on 2018/5/21/021.
//

#ifndef SECURITYAPP_MULTIOPENDETECTED_H
#define SECURITYAPP_MULTIOPENDETECTED_H


#include <jni.h>

int MultiOpen(JNIEnv *);


#endif //SECURITYAPP_MULTIOPENDETECTED_H
