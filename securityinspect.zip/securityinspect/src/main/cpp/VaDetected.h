//
// Created by Administrator on 2018/5/21/021.
//

#ifndef SECURITYAPP_VADETECTED_H
#define SECURITYAPP_VADETECTED_H


int  isRunInVa();


#endif //SECURITYAPP_VADETECTED_H
