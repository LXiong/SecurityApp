//
// Created by ffthy on 21/11/2017.
//

#ifndef SECURITYSDK_INJECTDETECTED_H
#define SECURITYSDK_INJECTDETECTED_H

int getimagebase();

#endif //SECURITYSDK_INJECTDETECTED_H
